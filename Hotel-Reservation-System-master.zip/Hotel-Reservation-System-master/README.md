# Hotel-Reservation-System
A console based java application.
The main feauture of the app is in it's simplicity and use of core OOP feautures like Abstraction, Polymorphism, Encapsulation and Inheritance.

The detailed description of parameters used are described below. One can modify it to suit their need.
The hotel has three categories of rooms: Super Delux, Delux and Luxury. Only the Delux and Super Delux have wi-fi facility in the rooms. 
Delux and Luxury rooms may have either single or double occupancy. Each rooms has a a default room rate that is adjustable. 
The system changes the status of room to “occupied” when it is reserved. There is a facility to cancel the reservation also. 
The booking is done for some number of days. When a room is reserved, the room charge (room rate * no. of days) is displayed. 
The system also shows the status of rooms (whether occupied or vacant) in each category. 

The program displays a menu of alternatives to:
1. Indicate the room type that needs to be booked 
2. Indicate the occpancy (single/double) in that category.

If the rooms in a particular category are full, your program asks the person if it is acceptable to be placed in the 
other category. If yes, appropriate room is assigned.
